package net.elias.usodesensores;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class sensorPriximidad_activity extends AppCompatActivity {
    private Sensor miSensor;
    private SensorManager administradorDeSensores;
    private SensorEventListener disparadorEventoSensor;
    TextView lblValor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_priximidad);

        lblValor = findViewById(R.id.lblValor);
        View act1 = findViewById(R.id.actProximidad);

        administradorDeSensores = (SensorManager)getSystemService(SENSOR_SERVICE);
        miSensor = administradorDeSensores.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        if(miSensor == null){
            Toast.makeText(this, "Su dispositivo no cuenta con un sensor de proximidad", Toast.LENGTH_LONG).show();
            finish();
        }else{
            Toast.makeText(this, "Sensor de proximidad detectado", Toast.LENGTH_SHORT).show();
        }

        disparadorEventoSensor = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                lblValor.setText("Valor: " + sensorEvent.values[0]);

                if(sensorEvent.values[0] < miSensor.getMaximumRange()){
                    lblValor.setBackgroundColor(Color.rgb(59, 143, 250 ));
                    lblValor.setTextColor(Color.rgb(3, 3, 3));
                    act1.setBackgroundColor(Color.rgb(234, 239, 182 ));
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
        iniciarSensor();
    }

    public void iniciarSensor(){
        administradorDeSensores.registerListener(disparadorEventoSensor, miSensor,(2000*1000));
    }

    public void detenerSensor(){
        administradorDeSensores.unregisterListener(disparadorEventoSensor);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        iniciarSensor();
        super.onResume();
    }
}