package net.elias.usodesensores;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class sensorLuminosidad extends AppCompatActivity {
    private Sensor miSensor;
    private SensorManager administradorDeSensores;
    private SensorEventListener disparadorEventoSensor;
    TextView lblValor2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_luminosidad);

        lblValor2 = findViewById(R.id.lvlValor2);
        View act2 = findViewById(R.id.act2);

        administradorDeSensores = (SensorManager)getSystemService(SENSOR_SERVICE);
        miSensor = administradorDeSensores.getDefaultSensor(Sensor.TYPE_LIGHT);

        if(miSensor == null){
            Toast.makeText(this, "Su dispositivo no cuenta con un sensor de luminosidad", Toast.LENGTH_LONG).show();
            finish();
        }else{
            Toast.makeText(this, "Sensor de luminosidad detectado", Toast.LENGTH_SHORT).show();
        }

        disparadorEventoSensor = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                lblValor2.setText("Valor: " + sensorEvent.values[0]);
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
        iniciarSensor();
    }

    public void iniciarSensor(){
        administradorDeSensores.registerListener(disparadorEventoSensor, miSensor,(2000*1000));
    }

    public void detenerSensor(){
        administradorDeSensores.unregisterListener(disparadorEventoSensor);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        iniciarSensor();
        super.onResume();
    }
}